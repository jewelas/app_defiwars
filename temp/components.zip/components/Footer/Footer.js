import React from "react";
import style from "./Footer.css";
import appStyle from "../../App.module.css";
import { NavLink } from "react-router-dom";

class Footer extends React.Component {
  render() {
    return (
      <div className={appStyle.flexauto}>
        <div className={appStyle.container}>
          <div className={style.footer}>
            <a href="https://www.twitter.com/DeFiWars_crypto">
              <img src="img/twitter.png" alt="Twitter" />
            </a>
            <a href="https://www.t.me/defiwarsfinance">
              <img src="img/telegram.png" alt"Telegram" />
            </a>
            <a href="https://discord.gg/7CQr6u2e">
              <img src="img/discord.png" alt="Discord" />
            </a>
	          <a href="https://www.reddit.com/r/DeFiWars_Finance">
	            <img src="img/reddit.png" alt="Reddit" />
	          </a>
          </div>
        </div>
      </div>
    );
  }
}

export default Footer;
